from setuptools import setup, find_packages

setup(
    name="Tetris_KG",
    version="1.0",
    author="club_finX",
    author_email='m@mail.ru',
    packages=find_packages(),
)
